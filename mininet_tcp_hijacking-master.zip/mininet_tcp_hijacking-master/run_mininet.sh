#!/bin/bash

sudo python tcp_hijacking.py

#!/bin/bash

ettercap -G --filter etter_filter_tcp_co &
